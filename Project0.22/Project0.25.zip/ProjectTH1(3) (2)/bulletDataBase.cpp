#include "stdafx.h"
#include "bulletDataBase.h"


HRESULT bulletDataBase::init()
{

	BULLETMANAGER->addBulletInfo("Red_B_Round",BIGROUND, 60,60, 20, 20,0);
	BULLETMANAGER->addBulletInfo("Blue_B_Round", BIGROUND, 60, 60, 20, 20, 1);
	BULLETMANAGER->addBulletInfo("Green_B_Round", BIGROUND, 60, 60, 20, 20, 2);
	BULLETMANAGER->addBulletInfo("Yellow_B_Round", BIGROUND, 60, 60, 20, 20, 3);


	BULLETMANAGER->addBulletInfo("Black_M_Round",MIDDLEROUND, 27, 28, 15, 15,0);
	BULLETMANAGER->addBulletInfo("Red_M_Round", MIDDLEROUND, 27, 28, 15, 15,1);
	BULLETMANAGER->addBulletInfo("Violet_M_Round", MIDDLEROUND, 27, 28, 15, 15,2);
	BULLETMANAGER->addBulletInfo("Blue_M_Round", MIDDLEROUND, 27, 28, 15, 15,3);
	BULLETMANAGER->addBulletInfo("Green_M_Round", MIDDLEROUND, 27, 28, 15, 15,4);
	BULLETMANAGER->addBulletInfo("Leaf_M_Round", MIDDLEROUND, 27, 28, 15, 15,5);
	BULLETMANAGER->addBulletInfo("Yellow_M_Round", MIDDLEROUND, 27, 28, 15, 15,6);
	BULLETMANAGER->addBulletInfo("White_M_Round", MIDDLEROUND, 27, 28, 15, 15,7);


	BULLETMANAGER->addBulletInfo("Gray_S_Round", SMALLROUND, 12, 12, 10, 10, 0);
	BULLETMANAGER->addBulletInfo("Red_S_Round", SMALLROUND, 12, 12, 10, 10, 1);
	BULLETMANAGER->addBulletInfo("Violet_S_Round", SMALLROUND, 12, 12, 10, 10, 2);
	BULLETMANAGER->addBulletInfo("Leaf_S_Round", SMALLROUND, 12, 12, 10, 10, 3);
	BULLETMANAGER->addBulletInfo("Yellow_S_Round", SMALLROUND, 12, 12, 10, 10, 4);
	BULLETMANAGER->addBulletInfo("Black_S_Round", SMALLROUND, 12, 12, 10, 10, 5);
	BULLETMANAGER->addBulletInfo("Scarlet_S_Round", SMALLROUND, 12, 12, 10, 10, 6);
	BULLETMANAGER->addBulletInfo("Blue_S_Round", SMALLROUND, 12, 12, 10, 10, 7);
	BULLETMANAGER->addBulletInfo("Green_S_Round", SMALLROUND, 12, 12, 10, 10, 8);
	BULLETMANAGER->addBulletInfo("Gold_S_Round", SMALLROUND, 12, 12, 10, 10, 9);


	BULLETMANAGER->addBulletInfo("Black_S_Star", SMALLSTAR, 14, 14, 10, 10, 0);
	BULLETMANAGER->addBulletInfo("Red_S_Star", SMALLSTAR, 14, 14, 10, 10, 1);
	BULLETMANAGER->addBulletInfo("Blue_S_Star", SMALLSTAR, 14, 14, 10, 10, 2);
	BULLETMANAGER->addBulletInfo("Violet_S_Star", SMALLSTAR, 14, 14, 10, 10, 3);
	BULLETMANAGER->addBulletInfo("Green_S_Star", SMALLSTAR, 14, 14, 10, 10, 4);
	BULLETMANAGER->addBulletInfo("Yellow_S_Star", SMALLSTAR, 14, 14, 10, 10, 5);
	BULLETMANAGER->addBulletInfo("White_S_Star", SMALLSTAR, 14, 14, 10, 10, 6);


	BULLETMANAGER->addBulletInfo("Gray_B_Star", BIGSTAR, 30, 27, 20, 20, 0);
	BULLETMANAGER->addBulletInfo("Red_B_Star", BIGSTAR, 30, 27, 20, 20, 1);
	BULLETMANAGER->addBulletInfo("Black_B_Star", BIGSTAR, 30, 27, 20, 20, 2);
	BULLETMANAGER->addBulletInfo("Blue_B_Star", BIGSTAR, 30, 27, 20, 20, 3);
	BULLETMANAGER->addBulletInfo("Cyon_B_Star", BIGSTAR, 30, 27, 20, 20, 4);
	BULLETMANAGER->addBulletInfo("Green_B_Star", BIGSTAR, 30, 27, 20, 20, 5);
	BULLETMANAGER->addBulletInfo("Yellow_B_Star", BIGSTAR, 30, 27, 20, 20, 6);


	return S_OK;
}

void bulletDataBase::release(void)
{
}

void bulletDataBase::update()
{
}

void bulletDataBase::render()
{
}

bulletDataBase::bulletDataBase()
{
}


bulletDataBase::~bulletDataBase()
{
}
