#pragma once
#include "gameNode.h"

class palyer;

#define ENEMYSIZEX 50
#define ENEMYSIZEY 50

class c_Enemy : public gameNode
{
public:
	RECT body;
	float angle;
	float speed;
	int HP;
	int score;
	POINT center;
	int time;

	HRESULT init(void);
	void release(void);
	void update(palyer* pl1);
	void render();

	c_Enemy();
	~c_Enemy();

	RECT getBody() { return body; }
	POINT getCenterPos() { return{ (body.left + body.right) / 2,(body.top + body.bottom) / 2 }; }

	void setMoving(float input_angle, float input_moveSpeed) { angle = input_angle; speed = input_moveSpeed; }
	int getTime() { return time; }



	int getHP() { return HP; }
	void demage(int input) { HP -= input; }
	POINT getPoint() { return center; }
};

