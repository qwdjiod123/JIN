#pragma once

#include "gameNode.h"
#define PLAYERSIZEX 29
#define PLAYERSIZEY 44
#define HITSIZEX 10
#define HITSIZEY 10
#define BOMBRADIUS 200
#define BOBMSPEED 1.5



class palyer : public gameNode
{
	enum state
	{
		STAY,
		LEFT,
		RIGHT
	};
	RECT rc;
	RECT hitPoint;
	RECT rc_bomb;
	float bombSpeed;
	POINT center;
	float speed;
	bool isHit;
	int time;
	int frameX;
	int state;
	int Itime;

	float power;
	int safe;
	int bomb;

public:

	HRESULT init();
	void release(void);
	void update();
	void render();

	void setisHit(bool input) { isHit = input; }
	POINT getCenter() { return center; }
	RECT getHitRect() { return hitPoint; }

	palyer();
	~palyer();
};

