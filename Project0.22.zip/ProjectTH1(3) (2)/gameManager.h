#pragma once
#include "singletonBase.h"
class gameManager :
	public singletonBase <gameManager>
{
	int score;
	float power;
	int player;
	int bomb;
public:

	HRESULT init(void);

	void addScore(int Score) { score += Score; }
	int getScore() { return score; }

	void setPower(float Power) { power = Power; }
	void addPower(float Power) { power += Power; }
	float getPower() { return power; }
	
	void addPlayer() { player++; }
	void deathPlayer() 
	{ 
		if (player > 0)
		{
			player--;
		}
	}
	int getPlayer() { return player; }

	void addBomb() { bomb++; }
	void usedBomb() 
	{
		if (bomb > 0)
		{
			bomb--;
		}
	}
	int getBomb() { return bomb; }

	gameManager();
	~gameManager();
};

