#include "stdafx.h"
#include "mainGame.h"
//============================================================
//		##	mainGame ���� �׵��� �ߴ� �ڵ��� �Ѵ� ##
//============================================================
mainGame::mainGame()
{
}


mainGame::~mainGame()
{
}


//==================================================================
//		## �ʱ�ȭ ## init(void)
//==================================================================
HRESULT mainGame::init(void)
{
	
	gameNode::init(TRUE);

	bulletData = new bulletDataBase;
	bulletData->init();
	GAMEMANAGER->init();
	g_Image = new gameImage;
	g_Image->init();
	player = new palyer;
	player->init();
	enemy = new c_Enemy;
	enemy->init();
	time = 0;
	pause = false;
	

	int ranX = RND->getFromIntTo(100, WINSIZEX - 100);
	int ranY = RND->getFromIntTo(100, 300);

	POINT temp_P = { ranX,ranY };

	c_pattern* temp;
	temp = new c_pattern;

	float angle = GetAngle(enemy->getCenterPos().x, enemy->getCenterPos().y, player->getCenter().x, player->getCenter().y);//����ź�� ���� getangle

	temp->init(A_SPREAD, 1 , 3, 5, enemy->getCenterPos(), BULLETMANAGER->findBulletInfo("Blue_B_Star"), 21, 0 , PI*2, 50);

	pattern.push_back(temp);

	c_pattern* temp2;
	temp2 = new c_pattern;


	temp2->init(A_SPREAD, 1, 3, 4, enemy->getCenterPos(), BULLETMANAGER->findBulletInfo("Blue_B_Star"), 21, 0, PI * 2, 50);

	pattern.push_back(temp2);


	/*c_pattern* temp2;
	temp2 = new c_pattern;


	temp2->init(A_SPREAD, 3, 5, enemy->getCenterPos(), BULLETMANAGER->findBulletInfo("��ź��"), 8, angle + PI / 4, angle - PI / 4, 20, 1, A_REFLECT, 1);

	pattern.push_back(temp2);
*/
	

	return S_OK;
}

//==================================================================
//		## ���� ## release(void)
//==================================================================
void mainGame::release(void)
{
	gameNode::release();
	delete g_Image;
	delete bulletData;

	delete enemy;

	pattern.clear();

}

//==================================================================
//		## ������Ʈ ## update(void)
//==================================================================
void mainGame::update(void)
{
	gameNode::update();
	if (!pause)
	{
		player->update();
		enemy->update(player);

		float angle = GetAngle(enemy->getCenterPos().x, enemy->getCenterPos().y, player->getCenter().x, player->getCenter().y);//����ź�� ���� getangle
		
		patternUpdate(1, player, enemy->getCenterPos());


		switchPattern(50, 1);
		if (time <= 550)
		{
			changeSpeed(20, 1, 0);
			changeAngle(40, 1, player);
			changeSpeed(40, 1, 3);
			changeInfo(40, 1, BULLETMANAGER->findBulletInfo("Red_B_Star"));
		}
		else
		{

		}
	}
	if (KEYMANAGER->isOnceKeyDown('P'))
	{
		pause = !pause;
	}
	if (KEYMANAGER->isOnceKeyDown(VK_SPACE))
	{
		for (int i = 0; i < pattern.size(); i++)
		{
			pattern[i]->release();
		}
	}

	//if (time %50==0)
	//{

	//	int ranX = RND->getFromIntTo(100, WINSIZEX - 100);
	//	int ranY = RND->getFromIntTo(100, 300);

	//	POINT temp_P = { ranX,ranY };

	//	c_pattern* temp;
	//	temp = new c_pattern;

	//	float angle = GetAngle(enemy->getCenterPos().x, enemy->getCenterPos().y, player.getCenter().x, player.getCenter().y);//����ź�� ���� getangle

	//	temp->init(A_SPREAD, 3, 3, enemy->getCenterPos(), BULLETMANAGER->findBulletInfo("ûź��"), 20, angle+ PI*2, angle,50 ,1, V_REFLECT,1);


	//	pattern.push_back(temp);
	//	/*base_angle += 0.1f;*/
	//}

	



	/*for (int i = 0; i < pattern.size(); i++)
	{
		for (int j = 0; j < pattern[i]->getBullets()->size(); j++)
		{
			if (pattern[i]->getBullets()->at(j)->getLineVector().size() > 0)
			{
				for (int k = 0; k < pattern[i]->getBullets()->at(j)->getLineVector().size(); k++)
				{
					if (pattern[i]->getBullets()->at(j)->getLineVector()[k]->getBulletTime()%50==10)
					{
						pattern[i]->getBullets()->at(j)->getLineVector()[k]->setTilt(0.003f);
					}
					
				}
			}
			else
			{
				if (pattern[i]->getBullets()->at(j)->getBulletTime() % 100 == 50)
				{
					pattern[i]->getBullets()->at(j)->setTilt(0.003f);
				}

			}
		}
	}*/

	/*for (int i = 0; i < pattern.size(); i++)
	{
		for (int j = 0; j < pattern[i]->getBullets()->size(); j++)
		{
			if (pattern[i]->getBullets()->at(j)->getLineVector().size() > 0)
			{
				for (int k = 0; k < pattern[i]->getBullets()->at(j)->getLineVector().size(); k++)
				{
					if (pattern[i]->getBullets()->at(j)->getLineVector()[k]->getBulletTime() % 100 == 50)
					{
						pattern[i]->getBullets()->at(j)->getLineVector()[k]->setBullet(PI + (pattern[i]->getBullets()->at(j)->getLineVector()[k]->getBulletAngle()));
					}
				}
			}
			else
			{
				if (pattern[i]->getBullets()->at(j)->getBulletTime() % 100 == 50)
				{
					pattern[i]->getBullets()->at(j)->setBullet(PI + pattern[i]->getBullets()->at(j)->getBulletAngle());
				}

			}
		}
	}
*/



	time++;
}
//=============================================================
//	## render(void) ## ����
//=============================================================
void mainGame::render(void)
{
	//��� �� ��Ʈ�� (������ �׳� �״�� �Ѱ�!!)
	PatBlt(getMemDC(), 0, 0, WINSIZEX, WINSIZEY, WHITENESS);
//=============================================================
	//�̰��� �׸��� ��½�Ű�� �ȴ�
	
	//�Ʒ� ��� ���� �̹��� �Ŵ����� ��밡����
	//���Ѱɷ� �˾Ƽ� ����ϸ� ��
	enemy->render();
	player->render();
	for (int i = 0; i < pattern.size(); i++)
	{
		pattern[i]->render(getMemDC());
	}
	IMAGEMANAGER->render("�������̽�", getMemDC(), 0, 0);
	PrintMousePos(getMemDC());
	//_bgImage->render(getMemDC());
	
	//IMAGEMANAGER->findImage("��ȿ��")->render(getMemDC());


//=============================================================
	//������� ������ HDC�� �׸��� (������ �״�� �Ѱ�!!)
	this->getBackBuffer()->render(getHDC());
}


void mainGame::addPattern(int P_Type,int P_number, int I_delay, int input_speed, POINT start_pos, BulletInfo * B_info, int inputWay, float i_maxA, float m_minA, int Rate, int input_reflect, int input_B_TYPE)
{
	c_pattern* temp;
	temp = new c_pattern;

	temp->init(P_Type, P_number, I_delay, input_speed, start_pos, B_info, inputWay, i_maxA, m_minA, Rate, input_reflect, input_B_TYPE);

	pattern.push_back(temp);
}

void mainGame::PrintMousePos(HDC hdc)
{
	char str[32];
	wsprintf(str, "x:%d y:%d", _ptMouse.x, _ptMouse.y);
	TextOut(hdc, 10, 10, str, strlen(str));

}




