#pragma once
#include "gameNode.h"
class gameImage : public gameNode
{
public:

	HRESULT init();
	void release(void);
	void update();
	void render();

	gameImage();
	~gameImage();
};

