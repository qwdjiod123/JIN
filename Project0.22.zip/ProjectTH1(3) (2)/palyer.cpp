#include "stdafx.h"
#include "palyer.h"



HRESULT palyer::init()
{
	center.x = (LEFTEND+RIGHTEND) / 2;
	center.y = BOTTOMEND - PLAYERSIZEY/2;

	rc = RectMakeCenter(center.x, center.y, PLAYERSIZEX, PLAYERSIZEY);
	hitPoint = RectMakeCenter(center.x, center.y, HITSIZEX, HITSIZEY);
	
	time = 0;
	Itime = 0;
	frameX = 0;
	speed = 4.0f;
	state = STAY;
	isHit = false;

	power = GAMEMANAGER->getPower();
	safe = GAMEMANAGER->getPlayer();
	bomb = GAMEMANAGER->getBomb();

	return S_OK;
}

void palyer::release(void)
{
}

void palyer::update()
{
	if (KEYMANAGER->isStayKeyDown(VK_DOWN))
	{
		
		if (rc.bottom > BOTTOMEND)
		{
			rc.bottom = BOTTOMEND;
			rc.top = BOTTOMEND - PLAYERSIZEY;
			center.y = (rc.top + rc.bottom) / 2;
		}
		if (center.y != BOTTOMEND - PLAYERSIZEY / 2)
		{
			center.y += speed;
		}
	}
	if (KEYMANAGER->isStayKeyDown(VK_UP))
	{
		
		if (rc.top < TOPEND)
		{
			rc.top = TOPEND;
			rc.bottom = TOPEND+PLAYERSIZEY;
			center.y = (rc.top + rc.bottom) / 2;
		}
		if (center.y != BOTTOMEND + PLAYERSIZEY / 2)
		{
			center.y -= speed;
		}
	}
	if (KEYMANAGER->isStayKeyDown(VK_LEFT))
	{
		
		if (rc.left < LEFTEND)
		{
			rc.left = LEFTEND;
			rc.right = LEFTEND+ PLAYERSIZEX;
			center.x = (rc.left + rc.right) / 2;
		}
		if (center.x != LEFTEND + PLAYERSIZEX / 2)
		{
			center.x -= speed;
		}
		state = LEFT;
	}
	if (KEYMANAGER->isStayKeyDown(VK_RIGHT))
	{
		
		if (rc.right > RIGHTEND)
		{
			rc.right = RIGHTEND;
			rc.left = RIGHTEND - PLAYERSIZEX;
			center.x = (rc.left + rc.right) / 2;
		}
		if (center.x != LEFTEND  - PLAYERSIZEX / 2)
		{
			center.x += speed;
		}
		state = RIGHT;
	}


	if (KEYMANAGER->isStayKeyDown(VK_LSHIFT))
	{
		speed = 2.0f;
	}
	if (KEYMANAGER->isOnceKeyUp(VK_LSHIFT))
	{
		speed = 4.0f;
	}

	if (KEYMANAGER->isOnceKeyUp(VK_LEFT) || KEYMANAGER->isOnceKeyUp(VK_RIGHT))
	{
		frameX = 0;
		state = STAY;
	}

	rc = RectMakeCenter(center.x, center.y, PLAYERSIZEX, PLAYERSIZEY);
	hitPoint = RectMakeCenter(center.x, center.y, HITSIZEX, HITSIZEY);

	if (time % 7 == 0)
	{
		if (state == STAY)
		{

			if (frameX >= 7)
			{
				frameX = 0;
			}
			frameX++;
		}
		else
		{
			if (frameX >= 7)
			{
				frameX = 4;
			}
			frameX++;
		}

	}
	
	if (isHit)
	{
		Itime++;
		if (Itime > 5)
		{
			Itime = 0;
			isHit = false;
		}
	}

	time++;
}

void palyer::render()
{
	if (isHit)
	{
		EllipseMake(getMemDC(), rc);
	}
	else
	{
		IMAGEMANAGER->frameRender("�÷��̾�", getMemDC(), rc.left, rc.top, frameX, state);
	}
	EllipseMake(getMemDC(), hitPoint);
}

palyer::palyer()
{
}


palyer::~palyer()
{
}
