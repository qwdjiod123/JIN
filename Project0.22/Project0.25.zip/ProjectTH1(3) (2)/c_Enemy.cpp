#include "stdafx.h"
#include "c_Enemy.h"
#include"palyer.h"

HRESULT c_Enemy::init(void)
{
	centerX = (LEFTEND + RIGHTEND) / 2;
	centerY = (TOPEND)+50;
	//centerY = (TOPEND + BOTTOMEND) / 2;
	body = RectMakeCenter(centerX, centerY, ENEMYSIZEX, ENEMYSIZEY);
	
	speed = 2;
	angle = 0;
	moveTime = 50;
	frameX = 0;
	time = 0;
	return S_OK;
}

void c_Enemy::release(void)
{

}

void c_Enemy::update(palyer* pl1)
{
	if (moveTime > 0)
	{
		centerX += cosf(angle)*speed;
		centerY += -sinf(angle)*speed;
		if (time % 3 == 0)
		{
			if (state==LEFT)
			{
				if (frameX > 1)
				{
					frameX--;
				}
			}
			else if (state == RIGHT)
			{
				if (frameX <= 2)
				{
					frameX++;
				}
				
			}
			
		}
		moveTime--;
	}
	else
	{
		stopMove();
	}

	if (time % 30 == 0)
	{
		if (state == STAY)
		{
			if (frameX >= 3)
			{
				frameX = 0;
			}
			frameX++;
		}
	}

	if (body.left < LEFTEND ||body.right>RIGHTEND)
	{
		if (body.right > RIGHTEND)
		{
			centerX = RIGHTEND - ENEMYSIZEX/2;
		}
		if (body.left < LEFTEND)
		{
			centerX = LEFTEND+ ENEMYSIZEX/2;
		}
		angle = PI - angle;
	}

	body = RectMakeCenter(centerX, centerY, 50, 50);
	RECT temp;
	if (IntersectRect(&temp, &pl1->getHitRect(), &body))
	{
		pl1->setisHit(true);
	}
	

	time++;
}

void c_Enemy::render()
{
	if (state == LEFT)
	{
		IMAGEMANAGER->frameRender("����", getMemDC(), body.left, body.top, frameX, 1);
	}
	else if (state == RIGHT)
	{
		IMAGEMANAGER->frameRender("����", getMemDC(), body.left, body.top, frameX, 2);
	}
	if (state == STAY)
	{
		IMAGEMANAGER->frameRender("����", getMemDC(), body.left, body.top, frameX, 0);
	}
}

c_Enemy::c_Enemy()
{
}


c_Enemy::~c_Enemy()
{
}

void c_Enemy::setMove(float XPos, float YPos, float MoveTime)
{
	if (XPos > RIGHTEND - ENEMYSIZEX / 2)
	{
		XPos = RIGHTEND - ENEMYSIZEX / 2;
	}

	if (XPos < LEFTEND + ENEMYSIZEX / 2)
	{
		centerX = LEFTEND + ENEMYSIZEX / 2;
	}

	if (moveTime > 0)
	{

	}
	else
	{
		angle = GetAngle(centerX, centerY, XPos, YPos);
		speed = GetDistance(centerX, centerY, XPos, YPos) / MoveTime;
		moveTime = MoveTime;
		if (angle<PI * 3 / 2 && angle>PI / 2)
		{
			state = LEFT;
			frameX = 3;
		}
		else
		{
			state = RIGHT;
			frameX = 0;
		}
	}
}
