#include "stdafx.h"
#include "c_pattern.h"
#include"palyer.h"

HRESULT c_pattern:: init(int P_Type, int P_number, int I_delay, int input_speed, POINT start_pos, BulletInfo* B_info, int inputWay, float i_maxA, float m_minA, int Rate, int input_reflect , int input_B_TYPE )
{
	
	if (P_Type == A_SPREAD)//������ Ȯ������
	{
		pattern = A_SPREAD;
		petternOver = false;
		angle = 0.0f;
		way = inputWay;
		maxAngle = i_maxA;
		minAngle = m_minA;
		start = start_pos;
		delay = 0;
		B_type = input_B_TYPE;
		speed = input_speed;
		reflect = input_reflect;
		P_bulletInfo = *B_info;
		rate = Rate;
		PatternNumber = P_number;
		time = 0;
		isNull = false;
		stop = true;
	}
	else if (P_Type == S_SPREAD)
	{
		pattern = S_SPREAD;
		petternOver = false;
		angle = 0.0f;
		way = inputWay;
		maxAngle = i_maxA;
		minAngle = m_minA;
		start = start_pos;
		isNull = false;
		delay = I_delay;
		B_type = input_B_TYPE;
		speed = input_speed;
		reflect = input_reflect;
		time = 0;
		P_bulletInfo = *B_info;
		waycount = 0;
		rate = Rate;
		PatternNumber = P_number;
		stop = true;
	}
	else if (P_Type == R_SPREAD)
	{
		pattern = R_SPREAD;
		petternOver = false;
		angle = 0.0f;
		way = inputWay;
		maxAngle = i_maxA;
		minAngle = m_minA;
		start = start_pos;
		isNull = false;
		delay = I_delay;
		B_type = input_B_TYPE;
		speed = input_speed;
		reflect = input_reflect;
		time = 0;
		P_bulletInfo = *B_info;
		waycount = way;
		rate = 0;
		PatternNumber = P_number;
		stop = true;
	}


	return S_OK;
}


HRESULT c_pattern::A_init(int P_Type,int I_delay, int input_B_Type, BulletInfo* B_info, POINT start_pos, int inputWay, float C_angle, float spread_Angle, int input_speed, int input_reflect)
{
	if (P_Type == A_SPREAD)//������ Ȯ������
	{
		pattern = A_SPREAD;
		petternOver = false;
		angle = 0.0f;
		way = inputWay;
		maxAngle = C_angle + (spread_Angle/2);
		minAngle = C_angle - (spread_Angle / 2);
		start = start_pos;
		delay = 0;
		B_type = input_B_Type;
		speed = input_speed;
		reflect = input_reflect;
		P_bulletInfo = *B_info;
		for (int i = 0; i < way; i++)
		{
			c_bullet* temp;
			temp = new c_bullet;
			temp->init(B_type, &P_bulletInfo, start, (minAngle*(way - i - 1) + maxAngle*i) / (way + 1), speed, reflect, speed - 2, speed);
			set.push_back(temp);
		}
		time = 0;
		isNull = false;
	}
	else if (P_Type == S_SPREAD)
	{
		pattern = S_SPREAD;
		petternOver = false;
		angle = 0.0f;
		way = inputWay;
		maxAngle = C_angle + (spread_Angle / 2);
		minAngle = C_angle - (spread_Angle / 2);
		start = start_pos;
		isNull = false;
		delay = I_delay;
		B_type = input_B_Type;
		speed = input_speed;
		reflect = input_reflect;
		time = -1;
		P_bulletInfo = *B_info;
		waycount = way;
	}


	return S_OK;
}

void c_pattern::release(void)
{
	for (int i = 0; i < set.size(); i++)
	{
		set[i]->release();
	}
	set.clear();
}

void c_pattern::update(POINT enemy, palyer* pl1)
{
	if(pattern==S_SPREAD)
	{
		if (!stop)
		{
			if (time%delay == 0 && waycount < way)
			{
				c_bullet* temp;
				temp = new c_bullet;
				temp->init(B_type, &P_bulletInfo, enemy, ((minAngle*(way - waycount - 1)) + (maxAngle*waycount)) / (way - 1), speed, reflect, speed - 2, speed);
				set.push_back(temp);
				waycount++;
			}
			if (time%rate == 0 && waycount == way)
			{
				waycount = 0;
			}
		}
		
		
	}

	else if (pattern == R_SPREAD)
	{
		if (!stop)
		{
			if (time%delay == 0)
			{
				c_bullet* temp;
				temp = new c_bullet;
				int randomAngle = RND->getInt(waycount);
				temp->init(B_type, &P_bulletInfo, enemy, (minAngle*randomAngle + maxAngle*(way - randomAngle)) / way, speed, reflect, speed - 2, speed);
				set.push_back(temp);
			}
		}
		
	}
	else
	{
		if (!stop)
		{
			if (time%rate == 0)
			{
				for (int i = 0; i < way; i++)
				{
					c_bullet* temp;
					temp = new c_bullet;
					temp->init(B_type, &P_bulletInfo, enemy, (minAngle*(way - i - 1) + maxAngle*i) / (way - 1), speed, reflect, speed - 2, speed);
					set.push_back(temp);
				}
			}
		}
	}

	for (int i = 0; i < set.size(); i++)
	{
		set[i]->update(pl1);
	}

	for (int i = 0; i < set.size(); i++)
	{
		if (set[i]->getIsFire() == false)
		{
			set.erase(set.begin() + i);
		}
	}

	if (set.empty())
	{
		isNull = true;
	}

	time++;
	
}

void c_pattern::update(palyer* pl1)
{
	if (pattern == S_SPREAD)
	{
		if (time <= 0 && waycount<way)
		{
			c_bullet* temp;
			temp = new c_bullet;
			temp->init(B_type, &P_bulletInfo, start, ((minAngle*(way - waycount - 1)) + (maxAngle*waycount)) / (way + 1), speed, reflect, speed - 2, speed);
			set.push_back(temp);
			time = delay;
			waycount++;
		}
	}

	if (pattern == R_SPREAD)
	{
		if (time <= 0)
		{
			c_bullet* temp;
			temp = new c_bullet;
			int randomAngle = RND->getInt(waycount);
			temp->init(B_type, &P_bulletInfo, start, (minAngle*randomAngle + maxAngle*(way - randomAngle)) / way, speed, reflect, speed - 2, speed);
			set.push_back(temp);
			time = delay;
		}
	}

	for (int i = 0; i < set.size(); i++)
	{
		set[i]->update(pl1);
	}

	for (int i = 0; i < set.size(); i++)
	{
		if (set[i]->getIsFire() == false)
		{
			set.erase(set.begin() + i);
		}
	}

	if (set.empty())
	{
		isNull = true;
	}

	if (time > 0)
	{
		time--;
	}


}



void c_pattern::render(HDC hdc)
{
	for (int i = 0; i < set.size(); i++)
	{
		set[i]->render();
	}
}

void c_pattern::setSpeed_T(int time, float Speed)
{
	{
		for (int i = 0; i < set.size(); i++)
		{
			if (set[i]->getBulletTime() == time)
			{
				set[i]->setSpeed(Speed);
			}
		}
	}
}

void c_pattern::setAngle_T(int time, float Angle)
{
	for (int i = 0; i < set.size(); i++)
	{
		if (set[i]->getBulletTime() == time)
		{
			set[i]->setAngle(Angle);
		}
	}
}

void c_pattern::setAngle_T(int time, class palyer * pl1)
{
	for (int i = 0; i < set.size(); i++)
	{
		if (set[i]->getBulletTime() == time)
		{
			float angle = GetAngle(set[i]->getCenter().x, set[i]->getCenter().y, pl1->getCenter().x, 
				pl1->getCenter().y);
			set[i]->setAngle(angle);
		}
	}
}

void c_pattern::setTilt_T(int time, float tilt)
{
	for (int i = 0; i < set.size(); i++)
	{
		if (set[i]->getBulletTime() == time)
		{
			set[i]->setTilt(tilt);
		}
	}
}

void c_pattern::setStdAngle_T(int time, float Angle)
{
	for (int i = 0; i < set.size(); i++)
	{
		if (set[i]->getBulletTime() == time)
		{
			set[i]->setStdAngle(Angle);
		}
	}
}

void c_pattern::setBulletType_T(int time, BulletInfo * info)
{
	for (int i = 0; i < set.size(); i++)
	{
		if (set[i]->getBulletTime() == time)
		{
			set[i]->setBulletInfo(info);
		}
	}
}

c_pattern::c_pattern()
{
}


c_pattern::~c_pattern()
{
}
