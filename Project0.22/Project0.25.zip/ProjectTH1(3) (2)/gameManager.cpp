#include "stdafx.h"
#include "gameManager.h"


HRESULT gameManager::init(void)
{
	score = 0;
	power = 0.00f;
	player = 3;
	bomb = 3;
	return S_OK;
}

gameManager::gameManager()
{
}


gameManager::~gameManager()
{
}
