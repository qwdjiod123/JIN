#include "stdafx.h"
#include "c_bullet.h"
#include"palyer.h"

HRESULT c_bullet::init(int B_Type, BulletInfo* B_info,POINT center, float C_angle,int speed, int I_reflcet,float min_speed,float max_speed, float input_acxel)
{
	
	isFire = true;
	moveSpeed = speed;
	x = center.x;
	y = center.y;
	bodySizeX = B_info->viewWidth;
	bodySizeY = B_info->viewHeight;
	hitSizeX = B_info->hitWidth;
	hitSizeY = B_info->hitHeight;
	B_bulletInfo = *B_info;
	body = RectMakeCenter(x, y, bodySizeX, bodySizeY);
	hitRc = RectMakeCenter(x, y, hitSizeX, hitSizeY);
	angle = C_angle;
	reflect = I_reflcet;
	acxel = input_acxel;
	B_type = B_Type;
	tilt = 0;
	R_left = false;
	R_right = false;
	R_top = false;
	R_bottom = false;


	if (B_type == V_REFLECT)
	{
		R_left = true;
		R_right = true;
		R_top = false;
		R_bottom = false;
	}
	else if (B_type == H_REFLECT)
	{
		R_left = false;
		R_right = false;
		R_top = true;
		R_bottom = true;
	}
	else if (B_type == Q_REFLECT)
	{
		R_left = true;
		R_right = true;
		R_top = true;
		R_bottom = false;
	}
	else if(B_type==A_REFLECT)
	{
		R_left = true;
		R_right = true;
		R_top = true;
		R_bottom = true;
	}
	


	return S_OK;
}

void c_bullet::release(void)
{
	
}

void c_bullet::update(palyer* pl1)
{
	
	singleUpdate();
	if (intersectEllipse(&pl1->getHitRect(), &hitRc))
	{
		pl1->setisHit(true);
	}
}

void c_bullet::render()
{
	singleRender();
}

void c_bullet::setBulletInfo(BulletInfo * input)
{
	B_bulletInfo = *input;
	bodySizeX = input->viewWidth;
	bodySizeY = input->viewHeight;
	hitSizeX = input->hitWidth;
	hitSizeY = input->hitHeight;
}

void c_bullet::singleUpdate()
{

	if (reflect > 0)
	{
		if (body.top <= TOPEND && R_top)
		{
			angle *= -1;
			reflect--;
			
		}

		if (body.bottom >= BOTTOMEND && R_bottom)
		{
			
			angle *= -1;
			reflect--;
		}

		if (body.left <= LEFTEND && R_left)
		{
			
				angle = PI - angle;
				reflect--;
		}

		if (body.right >= RIGHTEND&&R_right)
		{
			angle = PI - angle;
			reflect--;
		}
	}
	else
	{
		if (body.bottom <= TOPEND)
		{
			isFire = false;
		}

		if (body.top >= BOTTOMEND)
		{
			isFire = false;
		}

		if (body.right <= LEFTEND)
		{

			isFire = false;
		}

		if (body.left >= RIGHTEND)
		{
			isFire = false;
		}
		
	}
	

	angle += tilt;
	x += cosf(angle) * moveSpeed;		//x���� +cosf
	y += -sinf(angle) * moveSpeed;	    //y���� -sinf
	body = RectMakeCenter(x, y, bodySizeX, bodySizeY);
	hitRc = RectMakeCenter(x, y, hitSizeX, hitSizeY);
	BulletTime++;
}

void c_bullet::singleRender()
{
	IMAGEMANAGER->frameRender(B_bulletInfo.S_type, getMemDC(), body.left, body.top, B_bulletInfo.frameX, B_bulletInfo.frameY);
	
	/*if (KEYMANAGER->isToggleKey('A'));
	{
		EllipseMake(hdc, hitRc);
	}
	*/
}


c_bullet::c_bullet()
{
}


c_bullet::~c_bullet()
{
}
