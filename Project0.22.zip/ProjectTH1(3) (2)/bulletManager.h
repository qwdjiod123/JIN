#pragma once
#include "singletonBase.h"

#define LEFTEND 40
#define RIGHTEND 517
#define TOPEND 20
#define BOTTOMEND 580
#define STAGESIZEX 477
#define STAGESIZEY 560


struct BulletInfo
{
	string Name;
	int type;
	string S_type;
	float viewWidth;
	float viewHeight;
	float hitWidth;
	float hitHeight;
	int frameX;
	int frameY;
};

class bulletManager :public singletonBase <bulletManager>
{

	typedef map<string, BulletInfo*> BulletInfoList;
	typedef map<string, BulletInfo*>::iterator BulletInfoIter;

	BulletInfoList bulletInfoList;

public:

	HRESULT init(void);
	void release(void);

	BulletInfo* addBulletInfo(string strKey,int Type, int ViewWidth, int ViewHeight, float HitWidth, float HitHeight, int FrameX = 0, int FrameY = 0);

	BulletInfo* findBulletInfo(string strKey);
	//�̹��� Ű������ ����
	BOOL deleteBulletInfo(string strKey);
	//�̹��� ��ü ����
	BOOL deleteAll();

	bulletManager();
	~bulletManager();
};

