#pragma once
#include "gameNode.h"

class palyer;



#define ENEMYSIZEX 50
#define ENEMYSIZEY 60

class c_Enemy : public gameNode
{
public:
	enum state
	{
		LEFT,
		RIGHT,
		STAY
	};
	RECT body;
	float angle;
	float speed;
	int HP;
	int score;
	float centerX;
	float centerY;
	int time;
	int moveTime;
	int frameX;
	int state;


	HRESULT init(void);
	void release(void);
	void update(palyer* pl1);
	void render();

	c_Enemy();
	~c_Enemy();

	RECT getBody() { return body; }
	float getCenterX() { return centerX; }
	float getCenterY() { return centerY; }

	void setMove(float Angle, float Speed) { angle = Angle; speed = Speed; }
	void setMove(float XPos, float YPos, float MoveTime);
	void stopMove() { speed = 0; state = STAY; frameX = 0; }

	int getTime() { return time; }
	POINT getCenterPos() { POINT temp = { (long)centerX,(long)centerY };
	return temp;
	}




	int getHP() { return HP; }
	void demage(int input) { HP -= input; }
};

