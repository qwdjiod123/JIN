#include "stdafx.h"
#include "c_Enemy.h"
#include"palyer.h"

HRESULT c_Enemy::init(void)
{
	center.x = (LEFTEND + RIGHTEND) / 2;
	//center.y = (TOPEND)+50;
	center.y = (TOPEND + BOTTOMEND) / 2;
	body = RectMakeCenter(center.x, center.y, ENEMYSIZEX, ENEMYSIZEY);
	
	speed = 0;
	angle = 0;
	return S_OK;
}

void c_Enemy::release(void)
{

}

void c_Enemy::update(palyer* pl1)
{
	center.x += cosf(angle)*speed;
	center.y += -sinf(angle)*speed;
	if (body.left < LEFTEND ||body.right>RIGHTEND)
	{
		if (body.right > RIGHTEND)
		{
			center.x = RIGHTEND - ENEMYSIZEX/2;
		}
		if (body.left < LEFTEND)
		{
			center.x = LEFTEND+ ENEMYSIZEX/2;
		}
		angle = PI - angle;
	}

	body = RectMakeCenter(center.x, center.y, 50, 50);
	RECT temp;
	if (IntersectRect(&temp, &pl1->getHitRect(), &body))
	{
		pl1->setisHit(true);
	}
}

void c_Enemy::render()
{
	Ellipse(getMemDC(), body.left, body.top, body.right, body.bottom);
}

c_Enemy::c_Enemy()
{
}


c_Enemy::~c_Enemy()
{
}
