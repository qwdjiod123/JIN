#pragma once
#include "gameNode.h"
class bulletDataBase : public gameNode
{

public:

	HRESULT init();
	void release(void);
	void update();
	void render();

	bulletDataBase();
	~bulletDataBase();
};

