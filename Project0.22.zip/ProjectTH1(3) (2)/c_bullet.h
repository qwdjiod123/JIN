#pragma once
#include "gameNode.h"

class palyer;

class c_bullet : public gameNode
{
public:
	RECT body;
	float bodySizeX;
	float bodySizeY;
	RECT hitRc;
	float hitSizeX;
	float hitSizeY;
	float moveSpeed;
	float acxel;
	float angle;
	float x;
	float y;
	bool isFire;
	int reflect;
	BulletInfo B_bulletInfo;
	int B_type;
	float tilt;


	HRESULT init(int B_Type, BulletInfo* B_info,POINT center, float C_angle , int speed,int I_reflcet=0, float min_speed=0, float max_speed=0,float input_acxel=0);
	void release(void);
	void update(palyer* pl1);
	void render();
	int BulletTime=0;

	bool R_left;
	bool R_right;
	bool R_top;
	bool R_bottom;

	image* _bigred;
	bool isRed=false;


	void setPosition(POINT E_cannon) { x = E_cannon.x; y = E_cannon.y; }
	RECT getBulletRect() { return body; }	
	bool getIsFire() { return isFire; }
	int getBulletTime() { return BulletTime; }

	void setSpeed(int Speed) { moveSpeed = Speed; }
	float getSpeed() { return moveSpeed; }

	void setAngle(float Angle) { angle = Angle; }
	void setStdAngle(float Angle) { angle += Angle; }


	void setBulletInfo(BulletInfo* input);

	void setTilt(float Tilt) { tilt = Tilt/1000; }

	POINT getCenter() { POINT temp = { x,y }; return temp; }

	float getBulletAngle() { return angle; }

	void singleUpdate();
	void singleRender();



	c_bullet();
	~c_bullet();
};

