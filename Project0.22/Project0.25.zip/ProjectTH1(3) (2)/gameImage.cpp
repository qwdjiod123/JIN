#include "stdafx.h"
#include "gameImage.h"


HRESULT gameImage::init()
{
	IMAGEMANAGER->addFrameImage("����ź", "bigRound1.bmp", 248, 62, 4, 1, true, RGB(255, 0, 255));

	IMAGEMANAGER->addFrameImage("����ź", "middleRound.bmp", 216, 28, 8, 1, true, RGB(255, 0, 255));

	IMAGEMANAGER->addFrameImage("����ź", "smallRound.bmp", 120, 12, 10, 1, true, RGB(255, 0, 255));

	IMAGEMANAGER->addFrameImage("������", "smallStar.bmp", 98, 14, 7, 1, true, RGB(255, 0, 255));

	IMAGEMANAGER->addFrameImage("������", "bigStar.bmp", 210, 27, 7, 1, true, RGB(255, 0, 255));

	IMAGEMANAGER->addFrameImage("�÷��̾�", "playerMove.bmp", 232, 132, 8, 3, true, RGB(255, 0, 255));

	IMAGEMANAGER->addImage("�������̽�", "HUD2.bmp", 800, 600, true, RGB(255, 0, 255));

	IMAGEMANAGER->addFrameImage("����", "boss.bmp", 200, 180, 4, 3, true, RGB(255, 0, 255));
	return S_OK;
}

void gameImage::release(void)
{
}

void gameImage::update()
{
}

void gameImage::render()
{
}

gameImage::gameImage()
{
}


gameImage::~gameImage()
{
}
