#pragma once
#include "gameNode.h"


#include"gameImage.h"
#include"c_bullet.h"
#include"palyer.h"
#include "c_Enemy.h"
#include"c_pattern.h"
#include"bulletDataBase.h"


#include<math.h>
#include<time.h>	


class mainGame : public gameNode
{
public:

	c_Enemy* enemy;

	vector<c_pattern*> pattern;

	int time;

	int patternNumber;

	float base_angle;

	palyer* player;

	gameImage* g_Image;

	bool pause;

	bulletDataBase* bulletData;
	virtual HRESULT init(void);
	virtual void release(void);
	virtual void update(void);
	virtual void render();

	void addPattern(int P_Type, int P_number, int I_delay, int input_speed, POINT start_pos, BulletInfo* B_info, int inputWay, float i_maxA,float m_minA, int Rate, 
		int input_reflect = 0, int input_B_TYPE = NORMAL);

	void changeBulletAngle(int PatternNum,bool isOne, float Angle , float Tilt = 0);
	void changeBulletSpeed(int PatternNum, int Speed, float Acxel=0);



	void switchPattern(int time, int patternNumber)
	{
		for (int i = 0; i < pattern.size(); i++)
		{
			if (pattern[i]->getPatternNumber() == patternNumber)
			{
				if (pattern[i]->getTime() == time)
				{
					pattern[i]->patternSwitch();
				}
			}
		}
	}

	void changeSpeed(int time, int patternNumber,float speed)
	{
		for (int i = 0; i < pattern.size(); i++)
		{
			if (pattern[i]->getPatternNumber() == patternNumber)
			{
				pattern[i]->setSpeed_T(time, speed);
			}
		}
	}

	void changeInfo(int time, int patternNumber, BulletInfo* info)
	{
		for (int i = 0; i < pattern.size(); i++)
		{
			if (pattern[i]->getPatternNumber() == patternNumber)
			{
				pattern[i]->setBulletType_T(time, info);
			}
		}
	}

	void changeAngle(int time, int patternNumber, float angle)
	{
		for (int i = 0; i < pattern.size(); i++)
		{
			if (pattern[i]->getPatternNumber() == patternNumber)
			{
				pattern[i]->setAngle_T(time, angle);
			}
		}
	}

	void changeAngle(int time, int patternNumber, palyer* pl1)
	{
		for (int i = 0; i < pattern.size(); i++)
		{
			if (pattern[i]->getPatternNumber() == patternNumber)
			{
				pattern[i]->setAngle_T(time, pl1);
			}
		}
	}

	void patternUpdate(int patternNumber,palyer* pl1)
	{
		for (int i = 0; i < pattern.size(); i++)
		{
			if (pattern[i]->getPatternNumber() == patternNumber)
			{
				pattern[i]->update(pl1);
			}
		}
	}

	void patternUpdate(int patternNumber, palyer* pl1,POINT point)
	{
		for (int i = 0; i < pattern.size(); i++)
		{
			if (pattern[i]->getPatternNumber() == patternNumber)
			{
				pattern[i]->update(point,pl1);
			}
		}
	}




	void PrintMousePos(HDC hdc);

	mainGame();
	virtual ~mainGame();
};